package com.example.java;

public interface WeaponBehavior {
    public void useWeapon();
}
